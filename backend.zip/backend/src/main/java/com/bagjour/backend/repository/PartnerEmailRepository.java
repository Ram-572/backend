package com.bagjour.backend.repository;

import com.bagjour.backend.model.entity.PartnerEmailEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.Optional;

@Repository
public interface PartnerEmailRepository extends JpaRepository<PartnerEmailEntity, Long> {

    Optional<PartnerEmailEntity> findFirstByPartner_IdAndSentDate(Long partnerId, Date sentDate);
}
