package com.bagjour.backend.repository;

import com.bagjour.backend.model.entity.BoutiqueEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BoutiqueRepository extends JpaRepository<BoutiqueEntity, Long> {
}
