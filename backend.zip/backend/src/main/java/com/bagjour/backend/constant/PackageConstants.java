package com.bagjour.backend.constant;

public interface PackageConstants {

    String GOLD_PACKAGE = "Gold (10 Email)";
    String SILVER_PACKAGE = "Silver (5 Email)";

    Integer GOLD_MAX_EMAIL = 10;
    Integer SILVER_MAX_EMAIL = 5;
}
