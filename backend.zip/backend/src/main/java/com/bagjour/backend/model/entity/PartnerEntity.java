package com.bagjour.backend.model.entity;

import com.bagjour.backend.model.request.PartnerRequest;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@Entity(name = "tbl_partner")
public class PartnerEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String _package;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String contactNo;

    @Column(nullable = false)
    private Date creationDate;

    public PartnerEntity(PartnerRequest partnerRequest) {
        this._package = partnerRequest.get_package();
        this.name = partnerRequest.getName();
        this.email = partnerRequest.getEmail();
        this.contactNo = partnerRequest.getContactNo();
        this.creationDate = new Date();
    }
}
