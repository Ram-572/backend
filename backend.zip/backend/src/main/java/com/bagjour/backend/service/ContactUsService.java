package com.bagjour.backend.service;

import com.bagjour.backend.model.entity.ContactUsEntity;
import com.bagjour.backend.model.request.ContactUsRequest;
import com.bagjour.backend.repository.ContactUsRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional
public class ContactUsService {

    private final ContactUsRepository contactUsRepository;

    public ContactUsService(ContactUsRepository contactUsRepository) {
        this.contactUsRepository = contactUsRepository;
    }

    public void addContactUs(ContactUsRequest contactUsRequest) {
        ContactUsEntity contactUsEntity = new ContactUsEntity(contactUsRequest);
        contactUsRepository.save(contactUsEntity);
    }
}
