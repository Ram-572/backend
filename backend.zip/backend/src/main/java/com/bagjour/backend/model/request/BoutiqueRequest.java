package com.bagjour.backend.model.request;

import lombok.Data;

@Data
public class BoutiqueRequest {

    private String designer;
    private String productCondition;
    private Integer age;
    private String style;
    private String additionalNote;
    private String name;
    private String email;
    private String contactNo;
    private Object myFiles;
}
