package com.bagjour.backend.model.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@Entity(name = "tbl_partner_email")
public class PartnerEmailEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private PartnerEntity partner;

    @Column(nullable = false)
    private Long sentCount;

    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    private Date sentDate;
}
