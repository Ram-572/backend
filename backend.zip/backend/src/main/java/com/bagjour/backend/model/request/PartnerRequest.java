package com.bagjour.backend.model.request;

import lombok.Data;

@Data
public class PartnerRequest {

    private String _package;
    private String name;
    private String email;
    private String contactNo;
}
