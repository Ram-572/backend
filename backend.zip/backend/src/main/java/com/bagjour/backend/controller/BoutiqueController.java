package com.bagjour.backend.controller;

import com.bagjour.backend.model.entity.BoutiqueEntity;
import com.bagjour.backend.model.request.BoutiqueRequest;
import com.bagjour.backend.model.request.PartnerRequest;
import com.bagjour.backend.service.BoutiqueService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/boutique")
public class BoutiqueController {

    private final BoutiqueService boutiqueService;

    public BoutiqueController(BoutiqueService boutiqueService) {
        this.boutiqueService = boutiqueService;
    }

    @PostMapping("/add-boutique")
    public ResponseEntity<?> addBoutique(@RequestBody BoutiqueRequest boutiqueRequest) {
        BoutiqueEntity boutique = boutiqueService.addBoutique(boutiqueRequest);
        return ResponseEntity.status(HttpStatus.OK).body(boutique);
    }

    @PostMapping("/add-partner")
    public ResponseEntity<?> addPartner(@RequestBody PartnerRequest partnerRequest) {
        boutiqueService.addPartner(partnerRequest);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @PostMapping("/save-file/{id}")
    public ResponseEntity<?> saveFile(@RequestParam List<MultipartFile> images, @PathVariable Long id) {
        boutiqueService.saveImages(images, id);
        return ResponseEntity.status(HttpStatus.OK).build();
    }
}
