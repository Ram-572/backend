package com.bagjour.backend.model.entity;

import com.bagjour.backend.model.request.BoutiqueRequest;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@Entity(name = "tbl_boutique")
public class BoutiqueEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String designer;

    @Column(nullable = false)
    private String productCondition;

    @Column(nullable = false)
    private Integer age;

    @Column(nullable = false)
    private String style;

    @Column(nullable = false)
    private String additionalNote;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String contactNo;

    @Column(nullable = false)
    private Date creationDate;

    public BoutiqueEntity(BoutiqueRequest boutiqueRequest) {
        this.designer = boutiqueRequest.getDesigner();
        this.productCondition = boutiqueRequest.getProductCondition();
        this.age = boutiqueRequest.getAge();
        this.style = boutiqueRequest.getStyle();
        this.additionalNote = boutiqueRequest.getAdditionalNote();
        this.name = boutiqueRequest.getName();
        this.email = boutiqueRequest.getEmail();
        this.contactNo = boutiqueRequest.getContactNo();
        this.creationDate = new Date();
    }
}
