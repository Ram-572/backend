package com.bagjour.backend.model.request;

import lombok.Data;

@Data
public class ContactUsRequest {

    private String name;
    private String email;
    private String contactNo;
    private String additionalNote;
}
