package com.bagjour.backend.service;

import com.bagjour.backend.constant.PackageConstants;
import com.bagjour.backend.model.entity.BoutiqueEntity;
import com.bagjour.backend.model.entity.PartnerEmailEntity;
import com.bagjour.backend.model.entity.PartnerEntity;
import com.bagjour.backend.repository.PartnerEmailRepository;
import com.bagjour.backend.repository.PartnerRepository;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
@Transactional
public class EmailService {

    private final PartnerRepository partnerRepository;
    private final PartnerEmailRepository partnerEmailRepository;
    private final ExecutorService executorService = Executors.newFixedThreadPool(4);
    private volatile static List<PartnerEntity> partners;

    public EmailService(PartnerRepository partnerRepository, PartnerEmailRepository partnerEmailRepository) {
        this.partnerRepository = partnerRepository;
        this.partnerEmailRepository = partnerEmailRepository;
    }

    public void sendEmail(BoutiqueEntity boutique) {
        if (partners == null) {
            partners = partnerRepository.findAll();
        }
        System.out.println("Send email for boutique " + boutique.getId());
        executorService.execute(new SendEmailTask(boutique));
    }

    public void reloadPartners() {
        partners = partnerRepository.findAll();
    }

    private class SendEmailTask implements Runnable {

        private final BoutiqueEntity boutique;

        public SendEmailTask(BoutiqueEntity boutique) {
            this.boutique = boutique;
        }

        @SneakyThrows
        @Override
        public void run() {
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            Date now = formatter.parse(formatter.format(new Date()));
            System.out.println("Now: " + now);
            if (partners.isEmpty()) {
                System.out.println("No partners found");
            }

            for (PartnerEntity partner : partners) {
                Optional<PartnerEmailEntity> partnerEmailOp = partnerEmailRepository.findFirstByPartner_IdAndSentDate(partner.getId(), now);
                if (partnerEmailOp.isPresent()) {
                    PartnerEmailEntity partnerEmail = partnerEmailOp.get();
                    boolean toSent = (partner.get_package().equals(PackageConstants.GOLD_PACKAGE) && partnerEmail.getSentCount() < PackageConstants.GOLD_MAX_EMAIL)
                            || (partner.get_package().equals(PackageConstants.SILVER_PACKAGE) && partnerEmail.getSentCount() < PackageConstants.SILVER_MAX_EMAIL);
                    if (toSent) {
                        sendEmail(partner);
                        partnerEmail.setSentCount(partnerEmail.getSentCount() + 1);
                        partnerEmailRepository.save(partnerEmail);
                    }
                } else {
                    PartnerEmailEntity partnerEmail = new PartnerEmailEntity();
                    partnerEmail.setPartner(partner);
                    partnerEmail.setSentCount(1L);
                    partnerEmail.setSentDate(now);
                    sendEmail(partner);
                    partnerEmailRepository.save(partnerEmail);
                }
            }
        }

        private void sendEmail(PartnerEntity partner) {
            System.out.println("Send email to partner " + partner.getId() + " for boutique " + boutique.getId());
        }
    }
}
