package com.bagjour.backend.service;

import com.bagjour.backend.model.entity.BoutiqueEntity;
import com.bagjour.backend.model.entity.ImageEntity;
import com.bagjour.backend.model.entity.PartnerEntity;
import com.bagjour.backend.model.request.BoutiqueRequest;
import com.bagjour.backend.model.request.PartnerRequest;
import com.bagjour.backend.repository.BoutiqueRepository;
import com.bagjour.backend.repository.ImageRepository;
import com.bagjour.backend.repository.PartnerRepository;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.io.File;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class BoutiqueService {

    @Value("${constants.IMAGE_FILES_PATH}")
    private String IMAGE_FILES_PATH;

    private final BoutiqueRepository boutiqueRepository;
    private final PartnerRepository partnerRepository;
    private final ImageRepository imageRepository;
    private final EmailService emailService;

    public BoutiqueService(BoutiqueRepository boutiqueRepository, PartnerRepository partnerRepository, ImageRepository imageRepository, EmailService emailService) {
        this.boutiqueRepository = boutiqueRepository;
        this.partnerRepository = partnerRepository;
        this.imageRepository = imageRepository;
        this.emailService = emailService;
    }

    public BoutiqueEntity addBoutique(BoutiqueRequest boutiqueRequest) {
        BoutiqueEntity boutiqueEntity = new BoutiqueEntity(boutiqueRequest);
        boutiqueEntity = boutiqueRepository.save(boutiqueEntity);
        emailService.sendEmail(boutiqueEntity);
        return boutiqueEntity;
    }

    public void addPartner(PartnerRequest partnerRequest) {
        PartnerEntity partnerEntity = new PartnerEntity(partnerRequest);
        partnerRepository.save(partnerEntity);
    }

    @SneakyThrows
    public void saveImages(List<MultipartFile> multipartFiles, Long id) {
        Optional<BoutiqueEntity> boutiqueOp = boutiqueRepository.findById(id);
        if (boutiqueOp.isPresent()) {
            BoutiqueEntity boutique = boutiqueOp.get();

            for (MultipartFile file : multipartFiles) {
                File folder = new File(IMAGE_FILES_PATH + id);
                folder.mkdirs();

                String imagePath = IMAGE_FILES_PATH + id + "/" + file.getOriginalFilename();
                file.transferTo(new File(imagePath));

                ImageEntity image = new ImageEntity();
                image.setBoutique(boutique);
                image.setImageName(file.getOriginalFilename());
                imageRepository.save(image);
            }
        }
    }
}
