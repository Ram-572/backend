package com.bagjour.backend.model.entity;

import com.bagjour.backend.model.request.ContactUsRequest;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@Entity(name = "tbl_contact_us")
public class ContactUsEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String contactNo;

    @Column(nullable = false)
    private String additionalNote;

    @Column(nullable = false)
    private Date creationDate;

    public ContactUsEntity(ContactUsRequest contactUsRequest) {
        this.name = contactUsRequest.getName();
        this.email = contactUsRequest.getEmail();
        this.contactNo = contactUsRequest.getContactNo();
        this.additionalNote = contactUsRequest.getAdditionalNote();
        this.creationDate = new Date();
    }
}
